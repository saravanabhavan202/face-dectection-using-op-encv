# Face-dectection-using-OpenCV
Detect faces using webcam

Despription:
- The code detects faces using webcam as input. OpenCV Haarcascade is used for face detection.
